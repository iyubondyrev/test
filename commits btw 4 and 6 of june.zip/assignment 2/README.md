# Puzzle
## Group Assignment 2IRR00 2024 group 60
* Ivan Bondyrev
* Dainius Gelžinis 1995006
* Akvilė Lukauskaitė 1953648
* Aleksandr Nikolaev
* Aleksandr Vardanian 1942263

### Description
TODO: A short description of your logic puzzle type in your own words

### Short use case
TODO: include which input puzzle file to use for it, and what actions to take in the GUI, step by step

### Explanation
TODO: A short list and explanation of what design patterns you used/modified to implement what parts (classes, behavior) of YPA

### Deadline
[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/_p0yNlNQ)
