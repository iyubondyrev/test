package ypa;

/**
 * Dummy class, to enforce inclusion of {@code package-info.java}
 * from the top-level package into generated javadoc.
 *
 * @author Tom Verhoeff (Eindhoven University of Technology)
 */
public class Dummy {
    // left empty on purpose
}
