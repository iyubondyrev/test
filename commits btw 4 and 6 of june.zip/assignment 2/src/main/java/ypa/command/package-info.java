/**
 * Package holding all classes related to the command pattern.
 *
 * @author Tom Verhoeff (Eindhoven University of Technology)
 */
package ypa.command;
