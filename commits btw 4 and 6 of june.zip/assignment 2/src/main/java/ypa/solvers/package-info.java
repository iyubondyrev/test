/**
 * Package holding all classes related to puzzle solvers.
 *
 * @author Tom Verhoeff (Eindhoven University of Technology)
 */
package ypa.solvers;
